<!--<div class="item">-->
<!--                      <div class="package-box text-center">-->
<!--                          <div class="productSku" style="display: none;">LOGO_OLIVE_BRONZE</div>-->
<!--                          <h4 class="category">Bronze Logo <br> Package</h4>-->
<!--                          <span class="actual-price packgePrice">$19.00</span><span class="sale-price">$38.00</span>-->
<!--                          <div class="scroll">-->
<!--                              <ul style="margin-bottom: 18px;">-->
<!--                                 <li>1 Logo Ideas</li>-->
<!--                                  <li>1 Logo Designers</li>-->
<!--                                  <li>1 Revisions (Additional $9)</li>-->
<!--                                  <li>24 - 48 Hours Turn Around Time</li>-->
<!--                              </ul>-->
<!--                              <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">-->
<!--                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>-->
<!--                                 <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>-->
<!--                                  <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>-->
<!--                                  <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>-->
<!--                                  <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>-->
                                 
<!--                                 <li></li>-->
<!--                              </ul>-->
<!--                              <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">-->
<!--                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>-->
<!--                                 <li>100% Real Account Manager (No Bots)</li>-->
<!--                                  <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>-->
<!--                                  <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>-->
<!--                                  <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>-->
<!--                                  <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>-->
<!--                                  <li><i class="fa fa-check" aria-hidden="true"></i>24/7 After Sales Support (Email, Chat, Call, SMS, Whatsapp)</li>-->
<!--                                 <li></li>-->
<!--                              </ul>-->
<!--                          </div>-->
<!--                          <div class="clearfix"></div>-->
<!--                          <p class="add-on"></p>-->
<!--                        <ul class="ul-50">-->
<!--                              <a href="<?php echo $number_val;?>">-->
<!--                                 <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>-->
<!--                              </a>-->
<!--                              <a href="javascript:;" class="" onclick="setButtonURL()">-->
<!--                                 <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>-->
<!--                              </a>-->
<!--                        </ul>-->
<!--                          <a class="btn-order green-btn" href="<?php echo $path;?>order?pack=1">ORDER NOW</a>-->
<!--                      </div>-->
<!--        </div>-->
     <!--    <div class="item">
          <div class="package-box text-center">
                          <div class="productSku" style="display: none;">LOGO_OLIVE_SILVER</div>
                         <h4 class="category">Silver Logo<br> Package</h4>
                         <span class="actual-price packgePrice">$39.00</span><span class="sale-price">$78.00</span>
                         <div class="scroll" >
                            <ul style="margin-bottom: 18px;">
                               <li>2 Logo Concepts</li>
                                <li>By 2 Logo Designers</li>
                                <li>2 Revisions (Additional $9)</li>
                                <li>24 - 48 Hours Turn Around Time</li>
                               
                            </ul>
                            <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>
                                 
                                 <li></li>
                              </ul>
                            <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>24/7 After Sales Support (Email, Chat, Call, SMS, Whatsapp)</li>
                                 
                              </ul>
                         </div>
                         <div class="clearfix"></div>
                         <p class="add-on"></span></p>
                         <ul class="ul-50">
                            <a href="<?php echo $number_val;?>">
                               <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
                            </a>
                            <a href="javascript:;" class="" onclick="setButtonURL()">
                               <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
                            </a>
                         </ul>
                         <a class="btn-order green-btn" href="<?php echo $path;?>order?pack=2">ORDER NOW</a>
                      </div>
        </div>
        <div class="item">
          <div class="package-box seller text-center">
                         <div class="productSku" style="display: none;">LOGO_OLIVE_GOLD</div>
                         <h4 class="category">Gold Logo<br> Package</h4>
                         <span class="actual-price packgePrice">$69.00</span><span class="sale-price">$138.00</span>
                         <div class="scroll">
                            <ul style="margin-bottom: 18px;">
                               <li>4 Logo Concepts</li>
                                <li>By 4 Logo Designers</li>
                                <li>4 Revisions (Additional $9)</li>
                                <li>24 - 48 Hours Turn Around Time</li>
                                <li>Stationery Design (Business Card / Letterhead )</li>
                               
                            </ul>
                            <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>
                                 
                                 <li></li>
                              </ul>
                            <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>24/7 Support (Email, Chat, Call, SMS, Whatsapp)</li>
                                 <li></li>
                              </ul>
                         </div>
                         <div class="clearfix"></div>
                         <p class="add-on"></p>
                         <ul class="ul-50">
                            <a href="<?php echo $number_val;?>">
                               <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
                            </a>
                            <a href="javascript:;" class="asdf" onclick="setButtonURL()">
                               <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
                            </a>
                         </ul>
                         <a class="btn-order green-btn" href="<?php echo $path;?>order?pack=3">ORDER NOW</a>
                      </div>
        </div>
        <div class="item">
          <div class="package-box text-center">
                         <div class="productSku" style="display: none;">LOGO_OLIVE_PLATINUM</div>
                         <h4 class="category">Platinum Logo <br> Package</h4>
                         <span class="actual-price packgePrice">$119.00</span><span class="sale-price">$238.00</span>
                         <div class="scroll">
                            <ul style="margin-bottom: 18px;">
                               <li>6 Logo Concepts</li>
                                <li>By 6 Logo Designers</li>
                                <li>Unlimited Revisions</li>
                                <li>24 - 48 Hours Turn Around Time</li>
                                <li>Stationery Design (Business Card, Letterhead, Envelope)</li>
                                <li>Email Signature</li>
                            </ul>
                            <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>
                                 
                                 <li></li>
                              </ul>
                            <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>    
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
                                <li><i class="fa fa-check" aria-hidden="true"></i>24/7 Support (Email, Chat, Call, SMS, Whatsapp)</li>
                                 <li></li>
                              </ul>
                         </div>
                         <div class="clearfix"></div>
                         <p class="add-on"></span></p>
                         <ul class="ul-50">
                            <a href="<?php echo $number_val;?>">
                               <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
                            </a>
                            <a href="javascript:;" class="" onclick="setButtonURL()">
                               <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
                            </a>
                         </ul>
                         <a class="btn-order green-btn" href="<?php echo $path;?>order?pack=4">ORDER NOW</a>
                      </div>
        </div>
        <div class="item">
          <div class="package-box text-center">
                         <div class="productSku" style="display: none;">LOGO_OLIVE_INFINITE</div>
                         <h4 class="category">Diamond Logo  <br> Package</h4>
                         <span class="actual-price packgePrice">$169.00</span><span class="sale-price">$338.00</span>
                         <div class="scroll">
                            <ul style="margin-bottom: 18px;">
                                <li>8 Logo Concepts</li>
                                <li>By 8 Logo Designers</li>
                                <li>Unlimited Revisions</li>
                                <li>24 - 48 Hours Turn Around Time</li>
                                <li>Stationery Design (Business Card, Letterhead, Envelope, Invoice)</li>
                                <li>Social Media Designs (Facebook, Twitter, Youtube, Instagram)</li>
                                <li>Email Signature</li>
                               
                            </ul>
                            <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>
                                 
                                 <li></li>
                              </ul>
                            <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
                                   <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
                                   <li><i class="fa fa-check" aria-hidden="true"></i>24/7 Support (Email, Chat, Call, SMS, Whatsapp)</li>
                                 
                                 <li></li>
                              </ul>
                      </div>
                         <div class="clearfix"></div>
                         <p class="add-on"></span></p>
                         <ul class="ul-50">
                            <a href="<?php echo $number_val;?>">
                               <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
                            </a>
                            <a href="javascript:;" class="" onclick="setButtonURL()">
                               <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
                            </a>
                         </ul>
                         <a class="btn-order green-btn" href="<?php echo $path;?>order?pack=5">ORDER NOW</a>
                      </div>
        </div>

        <div class="item">
          <div class="package-box text-center">
                         <div class="productSku" style="display: none;">LOGO_OLIVE_INFINITE</div>
                         <h4 class="category">Titanium Logo  <br> Package</h4>
                         <span class="actual-price packgePrice">$219.00</span><span class="sale-price">$438.00</span>
                         <div class="scroll">
                            <ul style="margin-bottom: 18px;">
                                <li>Unlimited Logo Ideas</li>
                                <li>Unlimited Revisions</li>
                                <li>24 - 48 Hours Turn Around Time</li>
                                <li>Stationery Design (Business Card, Letterhead, Envelope, Invoice)</li>
                                <li>Social Media Designs (Facebook, Twitter, Youtube, Instagram)</li>
                                <li>Email Signature</li>
                               
                            </ul>
                            <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>
                                 
                                 <li></li>
                              </ul>
                            <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
                                 <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
                                 <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>
                                  <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
                                   <li><i class="fa fa-check" aria-hidden="true"></i>00% Custom Designs (No Template)</li>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>24/7 Support (Email, Chat, Call, SMS, Whatsapp)</li>
                                 
                                 <li></li>
                              </ul>
                      </div>
                         <div class="clearfix"></div>
                         <p class="add-on"></span></p>
                         <ul class="ul-50">
                            <a href="<?php echo $number_val;?>">
                               <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
                            </a>
                            <a href="javascript:;" class="" onclick="setButtonURL()">
                               <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
                            </a>
                         </ul>
                         <a class="btn-order green-btn" href="<?php echo $path;?>order?pack=6">ORDER NOW</a>
                      </div>
        </div> -->


        <div class="row">
              <div  class=" col-sm-12 inner-tabs">
                 <ul class="nav nav-pills">
            
            <li><a data-toggle="pill" href="#logod" class="active show">Abstract, Flat, Iconic</a></li>
            <li><a data-toggle="pill" href="#Illustrative" class="">Illustrative</a></li>
            <li><a data-toggle="pill" href="#3D" class="">3D</a></li>
            <li><a data-toggle="pill" href="#mascot" class="">Mascot</a></li>
            <li><a data-toggle="pill" href="#animation-logo">Animation Logo</a></li>
            
          </ul>
        <div class="tab-content pricingboxes">
         
          

          
          <div id="logod" class="tab-pane active">
            <?php
            $packages = $_SERVER['HTTP_HOST']; 
            $packages = $srcurl."new_updates/packages-logo.php"; 
            include($packages); 
            ?>
          </div>

          <div id="Illustrative" class="tab-pane ">
            <?php
            $packages = $_SERVER['HTTP_HOST']; 
            $packages = $srcurl."new_updates/packages-illustrative-logo.php"; 
            include($packages); 
            ?>
          </div>
          <div id="3D" class="tab-pane ">
            <?php
            $packages = $_SERVER['HTTP_HOST']; 
            $packages = $srcurl."new_updates/packages-3d-logo.php"; 
            include($packages); 
            ?>
          </div>
           <div id="mascot" class="tab-pane ">
            <?php
            $packages = $_SERVER['HTTP_HOST']; 
            $packages = $srcurl."new_updates/packages-mascot-logo.php"; 
            include($packages); 
            ?>
          </div>
           <div id="animation-logo" class="tab-pane ">
            
            <?php
            $packages = $_SERVER['HTTP_HOST']; 
            $packages = $srcurl."new_updates/packages-animation-logo.php"; 
            include($packages); 
            ?>
          </div>
        
          
        </div>
              </div>
        </div>
      
         