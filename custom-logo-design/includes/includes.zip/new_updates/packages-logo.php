<div  id="pricing-carosul"class="owl-carousel owl-theme pl-2 pr-2">
  <div class="item">
    <div class="package-box text-center">
     <!-- <div class="productSku" style="display: none;">LOGO_OLIVE_PLATINUM</div> -->
     <h4 class="category">Special Logo <br> Package</h4>
     <span class="actual-price packgePrice"> $19.00</span><span class="sale-price"> $138.00</span>
     <div class="scroll">
      <ul style="margin-bottom: 18px;">
       <li>1 Logo Concept</li>
      <li>By 1 Logo Designer</li>
      <li>2 Revisions (Additional $9)</li>
      <li>24 - 48 Hours Turn Around Time</li>
     </ul>
     <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
       <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
       <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
       <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
       <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
       <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>

       <li></li>
     </ul>
     <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
       <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
       <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
       <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
       <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>    
       <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
       <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
       <li><i class="fa fa-check" aria-hidden="true"></i>24/7 Support (Email, Chat, Call, SMS, Whatsapp)</li>
       <li></li>
     </ul>
   </div>
   <div class="clearfix"></div>
   <p class="add-on"></span></p>
   <ul class="ul-50">
    <a href="<?php echo $number_val;?>">
     <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
   </a>
   <a href="javascript:;" class="" onclick="setButtonURL()">
     <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
   </a>
 </ul>
 <a class="btn-order green-btn" href="<?php echo $path;?>order?pack=43">ORDER NOW</a>
</div>
</div>



<div class="item">
  <div class="package-box text-center">
   <!-- <div class="productSku" style="display: none;">LOGO_OLIVE_PLATINUM</div> -->
   <h4 class="category">Bronze Logo <br> Package</h4>
   <span class="actual-price packgePrice">$39.00</span><span class="sale-price">$58.00 </span>
   <div class="scroll">
    <ul style="margin-bottom: 18px;">
       <li>2 Logo Concepts</li>
      <li>By 2 Logo Designers</li>
      <li>3 Revisions (Additional $9)</li>
      <li>24 - 48 Hours Turn Around Time</li>
    </ul>
    <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>

     <li></li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>    
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>24/7 After Sales Support (Email, Chat, Call, SMS, Whatsapp)</li>
     <li></li>
   </ul>
 </div>
 <div class="clearfix"></div>
 <p class="add-on"></span></p>
 <ul class="ul-50">
  <a href="<?php echo $number_val;?>">
   <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
 </a>
 <a href="javascript:;" class="" onclick="setButtonURL()">
   <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
 </a>
</ul>
<a class="btn-order green-btn" href="<?php echo $path;?>order?pack=42">ORDER NOW</a>
</div>
</div>



<div class="item">
  <div class="package-box text-center">
   <!-- <div class="productSku" style="display: none;">LOGO_OLIVE_PLATINUM</div> -->
   <h4 class="category">Silver Logo <br> Package</h4>
   <span class="actual-price packgePrice"> $69.00 </span><span class="sale-price">$98.00</span>
   <div class="scroll">
    <ul style="margin-bottom: 18px;">
     <li>3 Logo Concepts</li>
      <li>By 3 Logo Designers</li>
      <li>4 Revisions (Additional $9)</li>
         <li>Stationery Design (Business Card)</li>
      <li>24 - 48 Hours Turn Around Time</li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>

     <li></li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>    
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>24/7 After Sales Support (Email, Chat, Call, SMS, Whatsapp)</li>
     <li></li>
   </ul>
 </div>
 <div class="clearfix"></div>
 <p class="add-on"></span></p>
 <ul class="ul-50">
  <a href="<?php echo $number_val;?>">
   <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
 </a>
 <a href="javascript:;" class="" onclick="setButtonURL()">
   <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
 </a>
</ul>
<a class="btn-order green-btn" href="<?php echo $path;?>order?pack=44">ORDER NOW</a>
</div>
</div>

<div class="item">
  <div class="package-box seller text-center">
   <!-- <div class="productSku" style="display: none;">LOGO_OLIVE_PLATINUM</div> -->
   <h4 class="category">Gold Logo <br> Package</h4>
   <span class="actual-price packgePrice"> $119.00  </span><span class="sale-price">$138.00 </span>
   <div class="scroll">
    <ul style="margin-bottom: 18px;">
     <li>4 Logo Concepts</li>
      <li>By 4 Logo Designers</li>
      <li>6 Revisions (Additional $9)</li>
      <li>24 - 48 Hours Turn Around Time</li>
      <li>Stationery Design (Business Card)</li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>

     <li></li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>    
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>24/7 After Sales Support (Email, Chat, Call, SMS, Whatsapp)</li>
     <li></li>
   </ul>
 </div>
 <div class="clearfix"></div>
 <p class="add-on"></span></p>
 <ul class="ul-50">
  <a href="<?php echo $number_val;?>">
   <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
 </a>
 <a href="javascript:;" class="" onclick="setButtonURL()">
   <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
 </a>
</ul>
<a class="btn-order green-btn" href="<?php echo $path;?>order?pack=45">ORDER NOW</a>
</div>
</div>
<div class="item">
  <div class="package-box text-center">
   <!-- <div class="productSku" style="display: none;">LOGO_OLIVE_PLATINUM</div> -->
   <h4 class="category">Platinum Logo <br> Package</h4>
   <span class="actual-price packgePrice"> $169.00 </span><span class="sale-price">  $238.00</span>
   <div class="scroll">
    <ul style="margin-bottom: 18px;">
     <li>5 Logo Concepts</li>
      <li>By 5 Logo Designers</li>
      <li>8 Revisions (Additional $9)</li>
      <li>24 - 48 Hours Turn Around Time</li>
      <li>Stationery Design (Business Card, Letterhead,Invoice)</li>
      <li>  Social Media Design (Facebook, Twitter, Youtube, Instagram)</li>
      <li>Email Signature</li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>

     <li></li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>    
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>24/7 After Sales Support (Email, Chat, Call, SMS, Whatsapp)</li>
     <li></li>
   </ul>
 </div>
 <div class="clearfix"></div>
 <p class="add-on"></span></p>
 <ul class="ul-50">
  <a href="<?php echo $number_val;?>">
   <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
 </a>
 <a href="javascript:;" class="" onclick="setButtonURL()">
   <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
 </a>
</ul>
<a class="btn-order green-btn" href="<?php echo $path;?>order?pack=46">ORDER NOW</a>
</div>
</div>

<div class="item">
  <div class="package-box text-center">
   <!-- <div class="productSku" style="display: none;">LOGO_OLIVE_PLATINUM</div> -->
   <h4 class="category">Diamond Logo <br> Package</h4>
   <span class="actual-price packgePrice"> $219.00 </span><span class="sale-price"> $338.00</span>
   <div class="scroll">
    <ul style="margin-bottom: 18px;">
    <li>6 Logo Concepts</li>
      <li>By 6 Logo Designers</li>
      <li>10 Revisions (Additional $9)</li>
      <li>24 - 48 Hours Turn Around Time</li>
      <li>  Stationery Design (Business Card, Letterhead, Invoice, Envelop)</li>
      <li>Social Media Designs (Facebook, Twitter, Youtube, Instagram)</li>
      <li>  2 Sided Flyer (OR) Bi-Fold Brochure Design</li>
      <li>Email Signature</li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>

     <li></li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>    
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>24/7 After Sales Support (Email, Chat, Call, SMS, Whatsapp)</li>
     <li></li>
   </ul>
 </div>
 <div class="clearfix"></div>
 <p class="add-on"></span></p>
 <ul class="ul-50">
  <a href="<?php echo $number_val;?>">
   <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
 </a>
 <a href="javascript:;" class="" onclick="setButtonURL()">
   <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
 </a>
</ul>
<a class="btn-order green-btn" href="<?php echo $path;?>order?pack=47">ORDER NOW</a>
</div>
</div>


<div class="item">
  <div class="package-box text-center">
   <!-- <div class="productSku" style="display: none;">LOGO_OLIVE_PLATINUM</div> -->
   <h4 class="category">Titanium Logo <br> Package</h4>
   <span class="actual-price packgePrice"> $249.00  </span><span class="sale-price">$438.00</span>
   <div class="scroll">
    <ul style="margin-bottom: 18px;">
      <li> 8 Logo Concepts</li>
      <li>  By 8 Logo Designers</li>
      <li>  12 Revisions (Additional $9)</li>
      <li>24 - 48 Hours Turn Around Time</li>
      <li>Stationery Design (Business Card, Letterhead, Envelope, Invoice)</li>
      <li>Social Media Designs (Facebook, Twitter, Youtube, Instagram)</li>
      <li>  Double Side Flyer (OR) Tri-Fold Brochure Design</li>
      <li>Email Signature</li>
    </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>

     <li></li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>    
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>24/7 After Sales Support (Email, Chat, Call, SMS, Whatsapp)</li>
     <li></li>
   </ul>
 </div>
 <div class="clearfix"></div>
 <p class="add-on"></span></p>
 <ul class="ul-50">
  <a href="<?php echo $number_val;?>">
   <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
 </a>
 <a href="javascript:;" class="" onclick="setButtonURL()">
   <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
 </a>
</ul>
<a class="btn-order green-btn" href="<?php echo $path;?>order?pack=48">ORDER NOW</a>
</div>
</div>


<div class="item">
  <div class="package-box text-center">
   <!-- <div class="productSku" style="display: none;">LOGO_OLIVE_PLATINUM</div> -->
   <h4 class="category">Infinite Logo <br> Package</h4>
   <span class="actual-price packgePrice"> $299.00 </span><span class="sale-price"> $438.00</span>
   <div class="scroll">
    <ul style="margin-bottom: 18px;">
      <li>Unlimited Logo Concepts</li>
      <li>By Award Winning Logo Designers</li>
      <li>Unlimited Revisions</li>
      <li>24 - 48 Hours Turn Around Time</li>
      <li>Stationery Design (Business Card, Letterhead, Invoice, Envelop)</li>
      <li>Social Media Designs (Facebook, Twitter, Youtube, Instagram)</li>
      <li>2 Sided Flyer (OR) Bi-Fold Brochure Design</li>
      <li>Double Side Flyer (OR) Tri-Fold Brochure Design</li>
      <li>T-Shirt, Signage, Packaging Design</li>
      <li>Email Signature</li>
      <li>FAX Template</li>
    </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px;">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Free</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Greyscale Format</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Color Options</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Final Files (.AI, .PSD, .EPS, .JPEG, .SVG, .PDF, Tiff)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>Icon</li>

     <li></li>
   </ul>
   <ul class="mt-0 border-new" style="border-top: 2px solid #24d193;margin: 20px 0px">
     <li style="color: #f93221;font-weight: bold;margin-top: 10px;">Features</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Real Account Manager (No Bots)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Approval Assurance</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Ownership Rights</li>    
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Money Back Guarantee</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>100% Custom Designs (No Template)</li>
     <li><i class="fa fa-check" aria-hidden="true"></i>24/7 After Sales Support (Email, Chat, Call, SMS, Whatsapp)</li>
     <li></li>
   </ul>
 </div>
 <div class="clearfix"></div>
 <p class="add-on"></span></p>
 <ul class="ul-50">
  <a href="<?php echo $number_val;?>">
   <li class="share-icon">Share your Idea? <br/><?php echo $number_text;?></li>
 </a>
 <a href="javascript:;" class="" onclick="setButtonURL()">
   <li class="discuss-icon">Want to Discuss <br/>Live Chat Now</li>
 </a>
</ul>
<a class="btn-order green-btn" href="<?php echo $path;?>order?pack=49">ORDER NOW</a>
</div>
</div>
</div>