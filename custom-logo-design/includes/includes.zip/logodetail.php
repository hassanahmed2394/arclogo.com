
  <div class="left">
    <h2>Logo designing at its Absolute Best</h2>
    <h3>Brand Logo’s create Brand Identity</h3>
    <p>We believe in creating brand identity through our brand logos. These logos are created by professionals with considerable experience, skill and qualification at rates that suit your pocket. These professionals ensure the logo settles with the brand theory and business idea and works only to enhance the purpose of branding.</p>
    <ul class="pointlisting">
      <li>Monogram logos (or lettermarks)</li>
      <li>Wordmarks (or logotypes)</li>
      <li>Pictorial marks (or logo symbols)</li>
      <li>Abstract logo marks</li>
      <li>Mascots</li>
      <li>The combination mark</li>
      <li>The emblem</li>
      
    </ul>
    <a href="<?php echo $path;?>order" class="btn-theme-outline">Get a logo design now</a>
  </div>
  <div class="right">
    <figure>
      <img src="<?php echo $basesurl;?>images/logoimage.svg">
    </figure>
  </div>
