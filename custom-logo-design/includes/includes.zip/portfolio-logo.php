 
  <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/senior-ville-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/senior-ville-big.png" width="268" height="267">
        </figure>
      </a>
    </li>
    <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/slingerz-wax-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/slingerz-wax-big.png"  width="268" height="267">
        </figure>
      </a>
    </li>
    
    <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/spruce-goose-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/spruce-goose-big.png" width="268" height="267">
        </figure>
      </a>
    </li>
    <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/swl-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/swl-big.png" width="268" height="267">
        </figure>
      </a>
    </li>
    <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/the-vet-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/the-vet-big.png" width="268" height="267">
        </figure>
      </a>
    </li>
     <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/13.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/13.png" width="268" height="267">
      </figure>
    </a>
  </li>
   <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/16.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/16.png" width="268" height="267">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-04.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-04.png" width="268" height="267">
      </figure>
    </a>
  </li>
  
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-07.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-07.png" width="268" height="267">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/14.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/14.png" width="268" height="267">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/15.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/15.png" width="268" height="267">
      </figure>
    </a>
  </li>

  
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-08.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-08.png" width="268" height="267">
      </figure>
    </a>
  </li>
 <!--  
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-12.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-12.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-13.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-13.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-14.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-14.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-15.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-15.png">
      </figure>
    </a>
  </li>
  
 <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-20.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-20.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-21.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-21.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-22.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-22.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-23.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-23.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-05.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-05.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-06.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-06.png">
      </figure>
    </a>
  </li>
    <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/southern-coast-gymnastics-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/southern-coast-gymnastics-big.png">
        </figure>
      </a>
    </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-24.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-24.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-25.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-25.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-26.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-26.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-27.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-27.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-28.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-28.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-29.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-29.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-30.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-30.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-31.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-31.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-32.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-32.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-33.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-33.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-34.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-34.png">
      </figure>
    </a>
  </li>
  
  <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/farari-boyz-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/farari-boyz-big.png">
        </figure>
      </a>
    </li>
    <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-16.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-16.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-17.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-17.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-18.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-18.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-19.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-19.png">
      </figure>
    </a>
  </li>
    <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/fishermens-catch-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/fishermens-catch-big.png">
        </figure>
      </a>
    </li>
  <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/fitness-mbs-llc-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/fitness-mbs-llc-big.png">
        </figure>
      </a>
    </li>

    <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/geeky-monkey-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/geeky-monkey-big.png">
        </figure>
      </a>
    </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-41.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-41.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-42.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-42.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-43.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-43.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-44.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-44.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-45.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-45.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-46.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-46.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-48.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-48.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-49.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-49.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-50.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-50.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-51.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-51.png">
      </figure>
    </a>
  </li>


  <li class="border-box-effect logoportfo" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/beef-squasher-big-inside.png">
      <figure>
        <img src="assets/images/portfolio/logo/thumbnails/beef-squasher-big.png">
      </figure>
    </a>
  </li>
  <li class="border-box-effect logoportfo" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/death-diva-big-inside.png">
      <figure>
        <img src="assets/images/portfolio/logo/thumbnails/death-diva-big.png">
      </figure>
    </a>
  </li>
  
    <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-09.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-09.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-10.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-10.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-11.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-11.png">
      </figure>
    </a>
  </li>
    <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/hope-ridge-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/hope-ridge-big.png">
        </figure>
      </a>
    </li>
    <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/lion-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/lion-big.png">
        </figure>
      </a>
    </li>
     <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/mad-dawg-customs-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/mad-dawg-customs-big.png">
        </figure>
      </a>
    </li>
     <li class="border-box-effect logoportfo" data-category="transition">
      <a class="" data-fancybox="port" tabindex="-1"  href="assets/images/portfolio/logo/inner/ror-big-inside.png">
        <figure>
          <img src="assets/images/portfolio/logo/thumbnails/ror-big.png">
        </figure>
      </a>
    </li>
    
    
    
    
<li class="logoportfo border-box-effect" data-category="transition">
  <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/1.png">
    <figure>
      <img src="<?php echo $basesurl;?>images/portfolio/logo/1.png">
    </figure>
  </a>
</li>
<li class="logoportfo border-box-effect" data-category="transition">
  <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/2.png">
    <figure>
      <img src="<?php echo $basesurl;?>images/portfolio/logo/2.png">
    </figure>
  </a>
</li>
<li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/3.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/3.png">
      </figure>
    </a>
  </li>

  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/4.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/4.png">
      </figure>
    </a>
  </li>
<li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/5.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/5.png">
      </figure>
    </a>
  </li>

  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/6.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/6.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/7.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/7.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-35.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-35.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-36.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-36.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-37.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-37.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-38.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-38.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-39.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-39.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-40.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-40.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/8.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/8.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/9.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/9.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/10.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/10.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/11.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/11.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/12.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/12.png">
      </figure>
    </a>
  </li>
 
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-01.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-01.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-02.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-02.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/logo/new-03.png">
      <figure>
        <img src="<?php echo $basesurl;?>images/portfolio/logo/new-03.png">
      </figure>
    </a>
  </li>

   -->