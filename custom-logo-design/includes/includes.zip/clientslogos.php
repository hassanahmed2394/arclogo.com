<section class="sponsors-sec">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <h2>Our Esteemed Clientele</h2>
            <ul>
               <li class="first"><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo1.jpg" alt="" width="40" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo2.png" alt="" width="223" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo3.jpg" alt="" width="173" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo4.png" alt="" width="181" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo5.jpg" alt="" width="317" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo6.png" alt="" width="146" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo7.jpg" alt="" width="87" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo8.jpg" alt="" width="175" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo9.png" alt="" width="286" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo10.jpg" alt="" width="269" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo11.jpg" alt="" width="133" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo12.jpg" alt="" width="127" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo13.jpg" alt="" width="80" height="40"></li>
               <li><img src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/spo14.jpg" alt="" width="122" height="40"></li>
               <li class="last"><img src="<?php echo $basesurl;?>images/spo15.jpg" alt="" width="156" height="40"></li>
            </ul>
         </div>
      </div>
   </div>
</section>