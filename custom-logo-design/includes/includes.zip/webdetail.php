<div class="row">
    <div class="col-sm-6 text-left">
    <h2>Developing Websites and Long Term Working Relationships</h2>
    <h3>Use the world wide web for all that it has to offer</h3>
    <p class="text-left">Websites are essential in the modern time and age to ensure a strong business model. These Websites make sure that your business grows at an exponentially high rate. At ArcLogo, we are determined to provide you with a website that generates traffic along with hinting at the essence of your business itself.</p>
    <ul class="pointlisting">
      <li>Parallex Web page design </li>
      <li>Wordpress Development </li>
      <li>Custom Website Development</li>
      <li>Portal Development</li>
      <li>Web Applications</li>
      
    </ul>
    <!-- <a href="<?php echo $path;?>order" class="btn-theme-outline">Get a website in just $259.99</a> -->
    <ul class="what-ul hidden-sm">
                                 <li><a href="javascript:;" name="for £18.99" class="btn-theme-outline popup_open">Let's Start</a></li>
                                 <li class="discuss-icon">

                                  <a href="javascript:;" class="btn " onclick="setButtonURL()">Want to Discuss <br class="br">Live Chat Now</a></li>
                              </ul>
  </div>
  <div class="col-sm-6 text-right">
    
    <figure>
      <img src="<?php echo $basesurl;?>images/websiteimage.svg">
    </figure>
  </div>

</div>