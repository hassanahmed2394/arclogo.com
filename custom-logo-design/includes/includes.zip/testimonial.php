<section class="dptestimonials">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h2>Businesses that leave a long lasting impact.</h2>
        <p>Creating Brilliance Together.</p>

        <ul class="testwrap testslider">
          <li>
            <div class="testbox">
              <div class="user">
                <h3>OG</h3>
              </div>
              <div class="usertest">
                <h4>Working with ArcLogo was a breeze!</h4>
                <p>I was so pleased to find a great designer who actually followed my design brief and provide the perfect Logo design and a great looking Product Sticker.  I am so thankful I chose to use work with ArcLogo!</p>
                <h6>Olivia George, Business Owner</h6>
                <div class="ratings">
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star-half-empty"></span>
                </div>
              </div>
            </div>
          </li>

          <li>
            <div class="testbox">
              <div class="user">
                <h3>JV</h3>
              </div>
              <div class="usertest">
                <h4>I'm happy to say that ArcLogo has played a major role...</h4>
                <p>in helping me build over 10+ logos for my clients in just 1 Day. I highly recommend the service to anyone who is looking to get great design options at a great price point.</p>
                <h6>John Vanderbeck, Business Owner</h6>
                <div class="ratings">
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                </div>
              </div>
            </div>
          </li>

          <li>
            <div class="testbox">
              <div class="user">
                <h3>TR</h3>
              </div>
              <div class="usertest">
                <h4>Very Happy With The Services</h4>
                <p>After I received my video I needed some minor changes and I felt like it would be a problem but as always, the staff at Video Proficient helped me through every step.</p>
                <h6>Tina Roth, Business Owner</h6>
                <div class="ratings">
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                </div>
              </div>
            </div>
          </li>

          <li>
            <div class="testbox">
              <div class="user">
                <h3>KA</h3>
              </div>
              <div class="usertest">
                <h4>Remodeled The Look</h4>
                <p>I run a small veterinary clinic for pets and Video Proficient provided me with the perfect makeover that I needed. Shoutout to the support team who were always super helpful! </p>
                <h6>Kyle Abbott, CEO</h6>
                <div class="ratings">
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star-half-empty"></span>
                </div>
              </div>
            </div>
          </li>

          <li>
            <div class="testbox">
              <div class="user">
                <h3>AM</h3>
              </div>
              <div class="usertest">
                <h4>Brilliant Responsive Work</h4>
                <p>We talk regarding web design services for our website and how it was affecting our rankings. The team provided us responsive web design services and SEO consultation too!</p>
                <h6>Antionio Moreno, Business Owner</h6>
                <div class="ratings">
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                </div>
              </div>
            </div>
          </li>

          <li>
            <div class="testbox">
              <div class="user">
                <h3>CR</h3>
              </div>
              <div class="usertest">
                <h4>Excellent Web Consultation For My Website</h4>
                <p>I was a bit confused when I got to LDH, and the excellent team helped us along the way! We’re more than happy working with them.</p>
                <h6>Erika Blackwell, Business Owner</h6>
                <div class="ratings">
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star"></span>
                  <span class="icon-star-half-empty"></span>
                </div>
              </div>
            </div>
          </li>

          

     

          
        </ul>
      </div>
    </div>
  </div>
</section>