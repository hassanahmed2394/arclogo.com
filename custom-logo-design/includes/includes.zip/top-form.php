<style type="text/css">
   .flag-container{display: none !important}
</style>
<div class="login-form">
                        <div class="sign-in-htm">
                           <h5 class="text-uppercase color-red margin-top-0">Up To 75% discount</h5>
                           <p class="color-black font-weight-bold">
                              Professional Logo & Web Design Solutions for You
                           </p>
                           <div class="form-group margin-bottom-0 text-center">
                              <form id="offerForm" class="offr-frm" action="webpages/topFormController.php" role="form" method="post" >
                                 <input type="hidden" name="text" id="" value="70% Discount Professional Solutions for Your">
                                 
                                 <input type="text" class="form-control" id="name" name="Name" aria-describedby="name" placeholder="Name" required="">
                                 <input type="email" class="form-control" id="email" name="Email" aria-describedby="email" placeholder="Email" required="">
                                 <input  id="phone-coun" class="form-control"name="Number" type="number" placeholder="Phone Number" required >

                                 <div id="offerFormResult" class="alert alert-success" style="font-size: 12px;display: none;">Congratulations! You've Signed up, For Further Assistance Start <a href="javascript:;" onclick="setButtonURL()"> Live Chat.</a></div>
                                 <div class="clearfix"></div>
                                 <p class="text-center signup-text">*Signup now to avail this deal</p>
                                 <input type="hidden" name="hiddencapcha">
                                 <input type="hidden" name="cip" value="">
                                 <button type="submit" class="btn">Let's Get Started</button>

                              </form>
                           </div>
                           <div class="hr"></div>
                        </div>
                     </div>
                     <script type="text/javascript">
                        setTimeout(function(){ 

    
   $('input[name="cip"]').val(ip);
   
}, 3000);

                     </script>