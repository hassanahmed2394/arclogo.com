<li class="logoportfo border-box-effect" data-category="transition">
  <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/1.png">
    <figure>
      <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/1.png">
    </figure>
  </a>
</li>
<li class="logoportfo border-box-effect" data-category="transition">
  <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/2.png">
    <figure>
      <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/2.png">
    </figure>
  </a>
</li>
<li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/3.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/3.png">
      </figure>
    </a>
  </li>

  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/4.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/4.png">
      </figure>
    </a>
  </li>
<li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/5.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/5.png">
      </figure>
    </a>
  </li>

  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/6.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/6.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/7.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/7.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/8.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/8.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/9.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/9.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/10.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/10.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/11.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/11.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/12.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/12.png">
      </figure>
    </a>
  </li>
<!--   <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/13.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/13.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/14.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/14.png">
      </figure>
    </a>
  </li>
  <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/15.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/15.png">
      </figure>
    </a>
  </li>

   <li class="logoportfo border-box-effect" data-category="transition">
    <a class="" data-fancybox="port" tabindex="-1"  href="<?php echo $basesurl;?>images/portfolio/app/16.png">
      <figure>
        <img  src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" data-src="<?php echo $basesurl;?>images/portfolio/app/16.png">
      </figure>
    </a>
  </li>
 -->