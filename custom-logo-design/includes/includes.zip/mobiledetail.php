
  <div class="left">
    <h2>Mobile Application Development for Growth</h2>
    <h3>Custom mobile apps that boost brand presence, revenue, and reputation.</h3>
    <p>Let your brand grow and expand with the help of a Mobile Application. Our Mobile Application services are backed by plenty of experience, fresh creative minds and a bond of trust with our clients.</p>
    <ul class="pointlisting">
      <li>iOS App Development</li>
      <li>Android App Development</li>
      <li>Game Application</li>
      <li>Virtual Reality  </li>
      <li>Augmented Reality </li>
      
    </ul>
    <a href="<?php echo $path;?>order" class="btn-theme-outline">Get a custom quote </a>
  </div>
  <div class="right">
    <figure>
      <img src="<?php echo $basesurl;?>images/mobileimage.svg">
    </figure>
  </div>
